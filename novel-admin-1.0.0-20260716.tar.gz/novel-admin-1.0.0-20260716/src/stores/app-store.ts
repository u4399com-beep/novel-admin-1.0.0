import { create } from "zustand";
import type { ViewType, Novel, Chapter, Category, Tag, Theme, Site } from "@/types";

interface AppState {
  // Navigation
  currentView: ViewType;
  setCurrentView: (view: ViewType) => void;

  // Selected novel for detail view
  selectedNovelId: string | null;
  selectedNovel: Novel | null;
  selectNovel: (novel: Novel | null) => void;

  // Selected chapter for editing
  selectedChapterId: string | null;
  setSelectedChapterId: (id: string | null) => void;

  // Sidebar
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;

  // Novel form dialog
  novelFormOpen: boolean;
  setNovelFormOpen: (open: boolean) => void;
  editingNovel: Novel | null;
  setEditingNovel: (novel: Novel | null) => void;

  // Chapter form dialog
  chapterFormOpen: boolean;
  setChapterFormOpen: (open: boolean) => void;
  editingChapter: Chapter | null;
  setEditingChapter: (chapter: Chapter | null) => void;

  // Refresh triggers
  refreshVersions: Record<string, number>;
  triggerRefresh: (key: string) => void;

  // Categories and tags for forms
  categories: Category[];
  setCategories: (cats: Category[]) => void;
  tags: Tag[];
  setTags: (t: Tag[]) => void;

  // Theme form dialog
  themeFormOpen: boolean;
  setThemeFormOpen: (open: boolean) => void;
  editingTheme: Theme | null;
  setEditingTheme: (theme: Theme | null) => void;

  // Site form dialog
  siteFormOpen: boolean;
  setSiteFormOpen: (open: boolean) => void;
  editingSite: Site | null;
  setEditingSite: (site: Site | null) => void;

  // Command palette
  commandPaletteOpen: boolean;
  setCommandPaletteOpen: (open: boolean) => void;

}

export const useAppStore = create<AppState>((set) => ({
  // Navigation
  currentView: "dashboard",
  setCurrentView: (view) =>
    set({ currentView: view, selectedNovelId: null, selectedNovel: null, selectedChapterId: null }),

  selectedNovelId: null,
  selectedNovel: null,
  selectNovel: (novel) => set({ selectedNovelId: novel?.id ?? null, selectedNovel: novel, selectedChapterId: null }),

  selectedChapterId: null,
  setSelectedChapterId: (id) => set({ selectedChapterId: id }),

  // Sidebar
  sidebarOpen: true,
  setSidebarOpen: (open) => set({ sidebarOpen: open }),

  // Novel form
  novelFormOpen: false,
  setNovelFormOpen: (open) => set({ novelFormOpen: open, ...(open && { editingNovel: null }) }),
  editingNovel: null,
  setEditingNovel: (novel) => set({ editingNovel: novel, novelFormOpen: novel !== null }),

  // Chapter form
  chapterFormOpen: false,
  setChapterFormOpen: (open) => set({ chapterFormOpen: open, editingChapter: null }),
  editingChapter: null,
  setEditingChapter: (chapter) => set({ editingChapter: chapter, chapterFormOpen: chapter !== null }),

  // Refresh triggers
  refreshVersions: {},
  triggerRefresh: (key) =>
    set((s) => ({
      refreshVersions: { ...s.refreshVersions, [key]: (s.refreshVersions[key] ?? 0) + 1 },
    })),

  // Categories and tags
  categories: [],
  setCategories: (cats) => set({ categories: cats }),
  tags: [],
  setTags: (t) => set({ tags: t }),

  // Theme form
  themeFormOpen: false,
  setThemeFormOpen: (open) => set({ themeFormOpen: open, ...(open && { editingTheme: null }) }),
  editingTheme: null,
  setEditingTheme: (theme) => set({ editingTheme: theme, themeFormOpen: theme !== null }),

  // Site form
  siteFormOpen: false,
  setSiteFormOpen: (open) => set({ siteFormOpen: open, ...(open && { editingSite: null }) }),
  editingSite: null,
  setEditingSite: (site) => set({ editingSite: site, siteFormOpen: site !== null }),

  // Command palette
  commandPaletteOpen: false,
  setCommandPaletteOpen: (open) => set({ commandPaletteOpen: open }),


}));