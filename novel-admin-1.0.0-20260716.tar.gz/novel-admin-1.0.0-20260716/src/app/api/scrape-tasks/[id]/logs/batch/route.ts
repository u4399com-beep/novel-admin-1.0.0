import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { withAuth } from "@/lib/api-auth";
import { sanitizeField, safeJson } from "@/lib/api-utils";

const MAX_BATCH_SIZE = 100;
const MAX_MESSAGE_LENGTH = 500;
const MAX_DETAIL_LENGTH = 1000;
const VALID_LEVELS = ["info", "warn", "error", "success"] as const;

export const POST = withAuth(async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  let body: { logs?: Array<{ level: string; message: string; url?: string; detail?: string }> };
  try {
    body = await safeJson(request);
  } catch {
    return NextResponse.json({ error: "无效的JSON" }, { status: 400 });
  }

  if (!Array.isArray(body.logs) || body.logs.length === 0 || body.logs.length > MAX_BATCH_SIZE) {
    return NextResponse.json({ error: `logs必须是1-${MAX_BATCH_SIZE}条记录的数组` }, { status: 400 });
  }

  try {
    // Verify task exists
    const taskExists = await db.scrapeTask.findUnique({ where: { id }, select: { id: true } });
    if (!taskExists) {
      return NextResponse.json({ error: "采集任务不存在" }, { status: 404 });
    }

    // Validate all log levels before inserting
    for (const log of body.logs) {
      if (!VALID_LEVELS.includes(log.level as typeof VALID_LEVELS[number])) {
        return NextResponse.json({ error: `无效的日志级别: ${log.level}` }, { status: 400 });
      }
      if (!sanitizeField(log.message, MAX_MESSAGE_LENGTH)) {
        return NextResponse.json({ error: "日志消息不能为空" }, { status: 400 });
      }
    }

    const data = body.logs.map((log) => ({
      taskId: id,
      level: log.level,
      message: sanitizeField(log.message, MAX_MESSAGE_LENGTH),
      url: log.url ? sanitizeField(log.url, 2048) : null,
      detail: log.detail ? sanitizeField(log.detail, MAX_DETAIL_LENGTH) : null,
    }));

    await db.scrapeLog.createMany({ data });

    return NextResponse.json({ created: data.length });
  } catch (error) {
    console.error("Batch create logs error:", error);
    return NextResponse.json({ error: "批量创建日志失败" }, { status: 500 });
  }
});