import { db } from "@/lib/db";
import { safeJson, sanitizeField, isPrismaError } from "@/lib/api-utils";
import { NextRequest, NextResponse } from "next/server";
import { invalidateCache } from "@/lib/cache";
import { withAuth } from "@/lib/api-auth";

const VALID_IDENTIFIER_RE = /^[a-zA-Z0-9_-]+$/;
const MAX_NAME_LENGTH = 200;
const MAX_DESCRIPTION_LENGTH = 2000;
const MAX_IDENTIFIER_LENGTH = 100;
const MAX_CONFIG_SIZE = 102400; // 100KB

// GET /api/themes/[id] - Get a single theme
export const GET = withAuth(async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const theme = await db.theme.findUnique({
      where: { id },
      include: {
        _count: { select: { sites: true } },
      },
    });

    if (!theme) {
      return NextResponse.json({ error: "主题不存在" }, { status: 404 });
    }

    return NextResponse.json(theme);
  } catch (error) {
    console.error("Get theme error:", error);
    return NextResponse.json({ error: "获取主题详情失败" }, { status: 500 });
  }
});

// PUT /api/themes/[id] - Update a theme
export const PUT = withAuth(async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    let body;
    try {
      body = await safeJson(request);
    } catch {
      return NextResponse.json({ error: "请求数据格式错误" }, { status: 400 });
    }
    const { name, description, identifier, preview, config, enabled } = body;

    if (name !== undefined && !name?.trim()) {
      return NextResponse.json({ error: "主题名称不能为空" }, { status: 400 });
    }
    if (name !== undefined && name.trim().length > MAX_NAME_LENGTH) {
      return NextResponse.json({ error: `主题名称不能超过${MAX_NAME_LENGTH}个字符` }, { status: 400 });
    }
    if (identifier !== undefined) {
      if (typeof identifier !== 'string' || !identifier.trim()) {
        return NextResponse.json({ error: "主题标识符不能为空" }, { status: 400 });
      }
      if (!VALID_IDENTIFIER_RE.test(identifier.trim())) {
        return NextResponse.json({ error: "主题标识符只能包含字母、数字、下划线和短横线" }, { status: 400 });
      }
      if (identifier.trim().length > MAX_IDENTIFIER_LENGTH) {
        return NextResponse.json({ error: `主题标识符不能超过${MAX_IDENTIFIER_LENGTH}个字符` }, { status: 400 });
      }
    }
    if (description !== undefined && typeof description === "string" && description.trim().length > MAX_DESCRIPTION_LENGTH) {
      return NextResponse.json({ error: `主题描述不能超过${MAX_DESCRIPTION_LENGTH}个字符` }, { status: 400 });
    }
    if (enabled !== undefined && typeof enabled !== 'boolean') {
      return NextResponse.json({ error: "enabled 必须是布尔值" }, { status: 400 });
    }
    if (config !== undefined && config) {
      const configStr = typeof config === "string" ? config : JSON.stringify(config);
      if (configStr.length > MAX_CONFIG_SIZE) {
        return NextResponse.json({ error: `主题配置大小不能超过${Math.floor(MAX_CONFIG_SIZE / 1024)}KB` }, { status: 400 });
      }
      try {
        JSON.parse(configStr);
      } catch {
        return NextResponse.json({ error: "主题配置必须是合法的JSON" }, { status: 400 });
      }
    }

    const theme = await db.theme.update({
      where: { id },
      data: {
        ...(name !== undefined && { name: sanitizeField(name, MAX_NAME_LENGTH) }),
        ...(description !== undefined && { description: sanitizeField(description, MAX_DESCRIPTION_LENGTH) || null }),
        ...(identifier !== undefined && { identifier: sanitizeField(identifier, MAX_IDENTIFIER_LENGTH) }),
        ...(preview !== undefined && { preview: sanitizeField(preview, 500) || null }),
        ...(config !== undefined && {
          config: (() => {
            try {
              return JSON.stringify(typeof config === "string" ? JSON.parse(config) : config);
            } catch {
              return JSON.stringify(config);
            }
          })(),
        }),
        ...(enabled !== undefined && { enabled: typeof enabled === 'boolean' ? enabled : true }),
      },
      include: {
        _count: { select: { sites: true } },
      },
    });

    invalidateCache("themes:list");

    return NextResponse.json(theme);
  } catch (error: unknown) {
    console.error("Update theme error:", error);
    if (isPrismaError(error, "P2002")) {
      return NextResponse.json({ error: "主题名称或标识符已存在" }, { status: 409 });
    }
    if (isPrismaError(error, "P2025")) {
      return NextResponse.json({ error: "主题不存在" }, { status: 404 });
    }
    return NextResponse.json({ error: "更新主题失败" }, { status: 500 });
  }
});

// DELETE /api/themes/[id] - Delete a theme
export const DELETE = withAuth(async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const existing = await db.theme.findUnique({
      where: { id },
      include: { _count: { select: { sites: true } } },
    });
    if (!existing) {
      return NextResponse.json({ error: "主题不存在" }, { status: 404 });
    }
    if (existing._count.sites > 0) {
      return NextResponse.json(
        { error: `无法删除：有 ${existing._count.sites} 个站点正在使用此主题` },
        { status: 409 }
      );
    }
    await db.theme.delete({ where: { id } });
    invalidateCache("themes:list");
    return NextResponse.json({ success: true });
  } catch (error: unknown) {
    console.error("Delete theme error:", error);
    if (isPrismaError(error, "P2025")) {
      return NextResponse.json({ error: "主题不存在" }, { status: 404 });
    }
    return NextResponse.json({ error: "删除主题失败" }, { status: 500 });
  }
});